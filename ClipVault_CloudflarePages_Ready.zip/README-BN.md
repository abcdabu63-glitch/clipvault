# ClipVault website — cleaned file structure

## কী পরিবর্তন করা হয়েছে
- Home, Help ও Contact পেজের inline CSS আলাদা `assets/css/site.css` ফাইলে নেওয়া হয়েছে।
- Tailwind configuration আলাদা `assets/js/tailwind-config.js` ফাইলে নেওয়া হয়েছে।
- Home page-এর product rendering/search controller `assets/js/home.js`-এ রাখা হয়েছে।
- Home page-এর product data আলাদা `assets/js/product-data.js`-এ রাখা হয়েছে; সব demo product record ও demo code mapping সরানো হয়েছে।
- Help ও Contact পেজের নিজস্ব JavaScript যথাক্রমে `assets/js/help.js` ও `assets/js/contact.js`-এ নেওয়া হয়েছে।
- Help/Contact পেজ থেকে duplicated Home controller সরানো হয়েছে।
- Home page-এর demo quick-code chips এবং empty-state-এর demo codes সরানো হয়েছে।
- Home page-এর product card, live Google Sheets data loading, video-code search, gallery, color selection, video URL copy, share link, Buy/Visit link, Best Seller tag এবং search-এর পরে horizontal Trending carousel যুক্ত করা হয়েছে।
- `DESIGN.md` অপরিবর্তিত রাখা হয়েছে।

## ফাইলের কাঠামো

- `Home.html` — Home page-এর HTML/design markup
- `Help.html` — Help & Tutorials page
- `Contact.html` — Contact page
- `assets/css/site.css` — তিনটি পেজের shared CSS
- `assets/js/tailwind-config.js` — Tailwind theme configuration
- `assets/js/product-data.js` — product data source-এর একক entry point
- `assets/js/home.js` — Home page-এর existing render/search behavior
- `assets/js/help.js` — Help page accordion behavior
- `assets/js/contact.js` — Contact form behavior
- `DESIGN.md` — design-system notes

## Google Sheets সংযোগ
`assets/js/product-data.js`-এ দুটি প্রকাশিত CSV URL যুক্ত করা আছে:
- `top` Sheet → হোমপেজের Trending Products
- `Meesho` Sheet → Meesho product data

প্রতিটি পেজ লোড হলে ব্রাউজার CSV পড়ার চেষ্টা করে। কোনো Sheet ব্যর্থ হলেও অন্য Sheet-এর ডেটা থাকলে সেটি ব্যবহার করা যাবে; পেজে ত্রুটির বার্তা দেখাবে। Sheets অবশ্যই `Publish to web` থেকে CSV হিসেবে প্রকাশিত থাকতে হবে।

### সমর্থিত কলাম
`video_code`, `product_id`, `product_name`, `product_url`, `video_URL`, `price_range`, `rating`, `rating_count`, `color_1`, `images_1`, `color_2`, `images_2` ইত্যাদি। আরও রঙ যোগ করতে `color_3` + `images_3`, `color_4` + `images_4` ইত্যাদি জোড়া কলাম যোগ করা যাবে। `images_N` সেলে একাধিক পূর্ণ HTTP/HTTPS image URL কমা দিয়ে আলাদা করুন; CSV-তে এমন সেল Google Sheets নিজে quote করবে। `best_seller` কলামে `Best Seller`, `true`, `yes` বা `1` থাকলে ট্যাগ দেখাবে।

### যাচাইয়ের অবস্থা
JavaScript syntax check এবং নমুনা CSV দিয়ে data parsing পরীক্ষা করা হয়েছে। এই রানটাইমে Google-এর CSV URL সরাসরি fetch করে লাইভ ডেটা যাচাই করা যায়নি, তাই আপলোড/হোস্ট করার পরে সাইটে খুলে দুই Sheet-এর live loading পরীক্ষা করতে হবে। `file://` থেকে খোলার বদলে hosting বা local web server দিয়ে চালানো ভালো।

## ব্যবহার
সব ফাইল একই `Mywebsite` ফোল্ডার কাঠামোতে রাখুন। HTML পেজগুলো `assets/css` ও `assets/js`-এর relative path ব্যবহার করে; ফাইলগুলো আলাদা করে সরাবেন না।
