(function() {
    // Accordion Toggle Behavior for Troubleshooting Section
    const accordions = document.querySelectorAll('.trouble-toggle');
    accordions.forEach(btn => {
      btn.addEventListener('click', function() {
        const isExpanded = this.getAttribute('aria-expanded') === 'true';
        const content = this.nextElementSibling;
        const icon = this.querySelector('.material-symbols-outlined:last-child');

        // Toggle state
        if (isExpanded) {
          this.setAttribute('aria-expanded', 'false');
          content.classList.add('hidden');
          if (icon) icon.style.transform = 'rotate(0deg)';
        } else {
          this.setAttribute('aria-expanded', 'true');
          content.classList.remove('hidden');
          if (icon) icon.style.transform = 'rotate(180deg)';
        }
      });
    });

    // Smooth In-Page Anchor Jumps with Offset Handling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        const targetId = this.getAttribute('href').substring(1);
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          e.preventDefault();
          targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  })();
