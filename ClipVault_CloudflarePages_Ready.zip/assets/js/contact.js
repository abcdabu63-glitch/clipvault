(function initContactController() {
    const form = document.getElementById('clipvault-contact-form');
    if (!form) return;

    const nameInput = document.getElementById('contact-name');
    const emailInput = document.getElementById('contact-email');
    const categorySelect = document.getElementById('contact-category');
    const messageInput = document.getElementById('contact-message');
    const charCounter = document.getElementById('char-counter');
    const resetBtn = document.getElementById('reset-form-btn');
    const statusMount = document.getElementById('status-banner-mount');

    const errorName = document.getElementById('error-name');
    const errorEmail = document.getElementById('error-email');
    const errorCategory = document.getElementById('error-category');
    const errorMessage = document.getElementById('error-message');

    // Real-time character counter
    messageInput.addEventListener('input', () => {
      const len = messageInput.value.trim().length;
      charCounter.textContent = `${len} / 10 min`;
      if (len >= 10) {
        charCounter.classList.remove('text-outline');
        charCounter.classList.add('text-primary');
        errorMessage.classList.add('hidden');
        errorMessage.classList.remove('flex');
      } else {
        charCounter.classList.add('text-outline');
        charCounter.classList.remove('text-primary');
      }
    });

    // Email validation regex helper
    function isValidEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // Input blur clearers
    nameInput.addEventListener('input', () => {
      if (nameInput.value.trim().length > 0) {
        errorName.classList.add('hidden');
        errorName.classList.remove('flex');
      }
    });

    emailInput.addEventListener('input', () => {
      if (isValidEmail(emailInput.value.trim())) {
        errorEmail.classList.add('hidden');
        errorEmail.classList.remove('flex');
      }
    });

    categorySelect.addEventListener('change', () => {
      if (categorySelect.value) {
        errorCategory.classList.add('hidden');
        errorCategory.classList.remove('flex');
      }
    });

    // Reset Handler
    resetBtn.addEventListener('click', () => {
      form.reset();
      charCounter.textContent = '0 / 10 min';
      charCounter.classList.add('text-outline');
      charCounter.classList.remove('text-primary');
      
      [errorName, errorEmail, errorCategory, errorMessage].forEach(el => {
        el.classList.add('hidden');
        el.classList.remove('flex');
      });

      statusMount.innerHTML = '';
      statusMount.classList.add('hidden');
      if (window.showToast) {
        window.showToast('Form fields cleared.');
      }
    });

    // Form Submission with Strict Honesty
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      
      let isValid = true;
      const nameVal = nameInput.value.trim();
      const emailVal = emailInput.value.trim();
      const catVal = categorySelect.value;
      const msgVal = messageInput.value.trim();

      // Validate Name
      if (!nameVal) {
        errorName.classList.remove('hidden');
        errorName.classList.add('flex');
        isValid = false;
      } else {
        errorName.classList.add('hidden');
        errorName.classList.remove('flex');
      }

      // Validate Email
      if (!emailVal || !isValidEmail(emailVal)) {
        errorEmail.classList.remove('hidden');
        errorEmail.classList.add('flex');
        isValid = false;
      } else {
        errorEmail.classList.add('hidden');
        errorEmail.classList.remove('flex');
      }

      // Validate Category
      if (!catVal) {
        errorCategory.classList.remove('hidden');
        errorCategory.classList.add('flex');
        isValid = false;
      } else {
        errorCategory.classList.add('hidden');
        errorCategory.classList.remove('flex');
      }

      // Validate Message length
      if (msgVal.length < 10) {
        errorMessage.classList.remove('hidden');
        errorMessage.classList.add('flex');
        isValid = false;
      } else {
        errorMessage.classList.add('hidden');
        errorMessage.classList.remove('flex');
      }

      if (!isValid) {
        if (window.showToast) {
          window.showToast('Please fix the highlighted fields to continue.');
        }
        return;
      }

      // Honest Success Status UI (Does not lie about sending)
      statusMount.innerHTML = `
        <div class="p-5 rounded-2xl bg-tertiary-fixed text-on-tertiary-fixed shadow-md flex items-start gap-4">
          <div class="w-10 h-10 rounded-xl bg-tertiary text-on-tertiary flex items-center justify-center shrink-0 mt-0.5">
            <span class="material-symbols-outlined text-[24px]">verified</span>
          </div>
          <div class="space-y-1.5 flex-1">
            <div class="flex items-center justify-between gap-2">
              <span class="font-headline-sm text-headline-sm font-bold text-on-tertiary-fixed">
                Demo Validation Successful
              </span>
              <span class="font-label-sm text-label-sm px-2.5 py-0.5 rounded-full bg-tertiary text-on-tertiary font-bold uppercase tracking-wider">
                Passed Checks
              </span>
            </div>
            <p class="font-body-md text-body-md text-on-tertiary-fixed-variant leading-relaxed">
              Your input passed all checks. Message transmission will be enabled once the backend contact service is configured in the upcoming phase.
            </p>
            <div class="pt-2 text-label-sm font-label-sm text-on-tertiary-fixed opacity-90 flex flex-wrap gap-x-4 gap-y-1">
              <span><strong>Sender:</strong> ${nameVal}</span>
              <span><strong>Target:</strong> ${catVal}</span>
              <span><strong>Status:</strong> Ready for Dispatch Pipe</span>
            </div>
          </div>
        </div>
      `;

      statusMount.classList.remove('hidden');
      statusMount.scrollIntoView({ behavior: 'smooth', block: 'center' });

      if (window.showToast) {
        window.showToast('Validation successful (Client Mode Verified)');
      }
    });

  })();
