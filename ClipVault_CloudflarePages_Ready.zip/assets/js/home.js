(function () {
  'use strict';
  const data = window.PRODUCT_DATA;
  let activeCode = null;
  const viewport = document.getElementById('dynamic-viewport');
  const codeInput = document.getElementById('code-input');
  const clearBtn = document.getElementById('clear-input-btn');
  const feedbackMsg = document.getElementById('query-feedback-msg');
  const sampleChips = document.querySelectorAll('.sample-chip');
  const appCanvas = document.getElementById('app-canvas');
  const viewMobileBtn = document.getElementById('view-mobile-btn');
  const viewTabletBtn = document.getElementById('view-tablet-btn');
  const viewDesktopBtn = document.getElementById('view-desktop-btn');

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function safeUrl(value) {
    try { const u = new URL(String(value || '')); return /^https?:$/.test(u.protocol) ? u.href : ''; }
    catch (_) { return ''; }
  }
  function setPreviewMode(mode) {
    appCanvas.classList.remove('preview-mobile', 'preview-tablet', 'preview-desktop');
    [viewMobileBtn, viewTabletBtn, viewDesktopBtn].forEach(b => {
      if (!b) return;
      b.classList.remove('bg-surface-container-lowest', 'text-primary', 'shadow-xs');
      b.classList.add('text-on-surface-variant');
    });
    const target = mode === 'mobile' ? viewMobileBtn : mode === 'tablet' ? viewTabletBtn : viewDesktopBtn;
    appCanvas.classList.add('preview-' + mode);
    if (target) target.classList.add('bg-surface-container-lowest', 'text-primary', 'shadow-xs');
    window.showToast('Preview mode: ' + mode);
  }
  if (viewMobileBtn) viewMobileBtn.addEventListener('click', () => setPreviewMode('mobile'));
  if (viewTabletBtn) viewTabletBtn.addEventListener('click', () => setPreviewMode('tablet'));
  if (viewDesktopBtn) viewDesktopBtn.addEventListener('click', () => setPreviewMode('desktop'));

  function getProductByUid(uid) {
    return [...data.meesho, ...data.trending].find(p => p.uid === uid);
  }
  function productImage(product, colorIndex, imageIndex) {
    const color = product.colors[colorIndex] || product.colors[0];
    return color && color.images[imageIndex] || color && color.images[0] || '';
  }
  function renderCard(product, isSharedTarget = false) {
    const firstColor = product.colors[0];
    const firstImage = firstColor && firstColor.images[0] || '';
    const colorsHtml = product.colors.length > 1 ? `
      <div class="flex flex-wrap items-center gap-2 mt-3" aria-label="Available colors">
        <span class="text-xs font-semibold text-on-surface-variant">Colors:</span>
        ${product.colors.map((color, i) => {
          const preview = color.images[0] || '';
          return `<button type="button" class="color-choice inline-flex items-center gap-1.5 rounded-full border border-outline-variant/60 px-2 py-1 text-xs bg-surface-container-lowest hover:border-primary" data-uid="${esc(product.uid)}" data-color-index="${i}" aria-label="Choose ${esc(color.name)}">
            ${preview ? `<img src="${esc(preview)}" alt="" loading="lazy" class="w-5 h-5 rounded-full object-cover border border-outline-variant/40" onerror="this.style.display='none'">` : '<span class="w-5 h-5 rounded-full bg-surface-container-high border border-outline-variant/40"></span>'}
            <span>${esc(color.name)}</span>
          </button>`;
        }).join('')}
      </div>` : '';
    const productUrl = safeUrl(product.productUrl);
    const videoUrl = safeUrl(product.videoUrl);
    return `<article id="${isSharedTarget ? 'shared-product-card' : ''}" class="product-card w-full max-w-3xl mx-auto bg-surface-container-lowest rounded-2xl border border-outline-variant/50 shadow-sm overflow-hidden ${isSharedTarget ? 'shared-product-highlight' : ''}" data-uid="${esc(product.uid)}" data-product-id="${esc(product.id)}" data-product-source="${esc(product.source)}">
      <div class="product-gallery relative w-full bg-surface-container-low flex items-center justify-center overflow-hidden" data-color-index="0" data-image-index="0" style="min-height:220px;max-height:460px;aspect-ratio: 4 / 3;touch-action:pan-y">
        ${firstImage ? `<img class="gallery-image w-full h-full object-contain absolute inset-0" src="${esc(firstImage)}" alt="${esc(product.title)}" loading="lazy" style="max-height:460px" onerror="if(!this.dataset.driveFallbackTried){this.dataset.driveFallbackTried='1';const m=this.src.match(/googleusercontent\.com\/d\/([^/?]+)/);if(m){this.src='https://drive.google.com/uc?export=view&id='+m[1];return}}this.style.display='none';this.nextElementSibling.classList.remove('hidden')"><div class="image-placeholder hidden absolute inset-0 flex flex-col items-center justify-center text-on-surface-variant gap-2 p-6"><span class="material-symbols-outlined text-4xl">image_not_supported</span><span class="text-sm">Image unavailable</span></div>` : `<div class="image-placeholder absolute inset-0 flex flex-col items-center justify-center text-on-surface-variant gap-2 p-6"><span class="material-symbols-outlined text-4xl">image</span><span class="text-sm">Product image not provided</span></div>`}
        <div class="absolute top-3 left-3 z-10 flex flex-wrap gap-2">
          <button type="button" data-action="copy-video" data-uid="${esc(product.uid)}" class="rounded-full bg-white/95 text-slate-800 border border-slate-200 shadow px-3 py-2 text-xs font-bold inline-flex items-center gap-1.5 min-h-[38px] ${videoUrl ? '' : 'opacity-90'}" ${videoUrl ? '' : 'title="Video URL not available"'}><span class="material-symbols-outlined text-[16px]">content_copy</span>${videoUrl ? 'Copy Video URL' : 'Video URL unavailable'}</button>
        </div>
        <span class="absolute top-3 right-3 z-10 rounded-full ${product.bestSeller ? 'bg-amber-300 text-amber-950 border-amber-400' : 'bg-white/95 text-slate-700 border-slate-200'} border shadow px-2.5 py-1 text-[10px] font-extrabold tracking-wide">${product.bestSeller ? '# BEST SELLER' : (product.source === 'meesho' ? 'MEESHO' : 'TRENDING')}</span>
        ${product.colors.length && product.colors.some(c => c.images.length > 1) ? `<button type="button" data-action="gallery-prev" data-uid="${esc(product.uid)}" aria-label="Previous image" class="gallery-prev absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 w-9 h-9 shadow flex items-center justify-center">‹</button><button type="button" data-action="gallery-next" data-uid="${esc(product.uid)}" aria-label="Next image" class="gallery-next absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 w-9 h-9 shadow flex items-center justify-center">›</button>` : ''}
        <div class="absolute bottom-3 right-3 z-10 rounded-full bg-black/60 text-white text-[11px] px-2 py-1 gallery-counter">${firstColor && firstColor.images.length > 1 ? '1 / ' + firstColor.images.length : ''}</div>
      </div>
      <div class="p-4 sm:p-5 flex flex-col gap-3">
        <div class="flex flex-wrap items-center justify-between gap-2 text-xs text-on-surface-variant">
          <span class="font-semibold uppercase tracking-wide">${product.videoCode ? 'Video code: ' + esc(product.videoCode) : 'Product'}</span>
          ${product.id ? `<span class="rounded-md bg-surface-container px-2 py-1">ID: ${esc(product.id)}</span>` : ''}
        </div>
        <h3 class="text-lg sm:text-xl font-bold text-on-surface leading-snug">${esc(product.title)}</h3>
        ${product.description ? `<p class="text-sm text-on-surface-variant leading-relaxed">${esc(product.description)}</p>` : ''}
        ${colorsHtml}
        <div class="pt-3 mt-1 border-t border-outline-variant/30 flex flex-wrap items-end justify-between gap-3">
          <div class="space-y-1">
            ${product.price ? `<div class="text-lg font-bold text-on-surface">${esc(product.price)}</div>` : ''}
            ${product.rating ? `<div class="text-xs font-semibold text-on-surface-variant flex items-center gap-1"><span class="text-amber-500">★</span>${esc(product.rating)}${product.ratingCount ? ` <span class="font-normal">(${esc(product.ratingCount)})</span>` : ''}</div>` : ''}
          </div>
          <div class="flex flex-wrap gap-2">
            <button type="button" data-action="share" data-uid="${esc(product.uid)}" class="min-h-[44px] px-3 py-2 rounded-xl border border-outline-variant text-on-surface text-sm font-semibold inline-flex items-center gap-1.5"><span class="material-symbols-outlined text-[17px]">share</span>Share</button>
            <a ${productUrl ? `href="${esc(productUrl)}" target="_blank" rel="noopener noreferrer"` : 'aria-disabled="true" tabindex="-1"'} class="min-h-[44px] px-4 py-2 rounded-xl ${productUrl ? 'bg-primary text-on-primary' : 'bg-surface-container text-on-surface-variant'} text-sm font-semibold inline-flex items-center gap-1.5 ${productUrl ? '' : 'pointer-events-none'}">${productUrl ? 'Buy / Visit' : 'Product URL missing'} <span class="material-symbols-outlined text-[17px]">open_in_new</span></a>
          </div>
        </div>
      </div>
    </article>`;
  }

  function renderCardList(products, horizontal) {
    if (!products.length) return '<div class="max-w-3xl mx-auto rounded-2xl border border-dashed border-outline-variant p-8 text-center text-sm text-on-surface-variant">No products are available in this section yet.</div>';
    return `<div class="${horizontal ? 'trending-carousel flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory no-scrollbar' : 'flex flex-col gap-5 sm:gap-6'}">${products.map(p => horizontal ? `<div class="snap-start shrink-0 w-[88%] sm:w-[520px]">${renderCard(p)}</div>` : renderCard(p)).join('')}</div>`;
  }

  function dataStatus() {
    const issues = [];
    if (data.errors.top) issues.push('Trending Sheet: ' + data.errors.top);
    if (data.errors.meesho) issues.push('Meesho Sheet: ' + data.errors.meesho);
    return issues.length ? `<div class="max-w-3xl mx-auto mb-5 rounded-xl border border-amber-300 bg-amber-50 text-amber-900 p-3 text-sm"><strong>Some sheet data could not load.</strong><ul class="list-disc pl-5 mt-1">${issues.map(x => '<li>' + esc(x) + '</li>').join('')}</ul><p class="mt-1 text-xs">Check that each sheet is published as CSV and that its URL is still valid.</p></div>` : '';
  }

  function renderTrendingView() {
    viewport.innerHTML = `${dataStatus()}<section class="w-full">
      <div class="max-w-3xl mx-auto mb-5 sm:mb-7"><div class="flex flex-wrap items-center gap-2 mb-1"><h2 class="text-xl sm:text-2xl font-bold text-on-surface">Trending Products</h2><span class="rounded-full bg-secondary-fixed text-on-secondary-fixed px-2 py-1 text-[10px] font-bold uppercase">Latest list</span></div><p class="text-sm text-on-surface-variant">Products loaded from the published top Google Sheet.</p></div>
      ${data.trending.length ? renderCardList(data.trending, false) : `<div class="max-w-3xl mx-auto rounded-2xl border border-dashed border-outline-variant p-8 text-center"><p class="font-semibold text-on-surface">No Trending Products loaded</p><p class="text-sm text-on-surface-variant mt-2">The top sheet may be empty or could not be read. Check the published CSV and the column headers.</p></div>`}
    </section>`;
  }

  function renderSearchResultsView(code, productIds) {
    const products = productIds.map(getProductByUid).filter(Boolean);
    viewport.innerHTML = `${dataStatus()}<section class="w-full">
      <div class="max-w-3xl mx-auto p-4 sm:p-6 rounded-2xl bg-surface-container-low border border-outline-variant/40 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 class="text-lg sm:text-2xl font-bold text-on-surface">Search Results: <span class="text-primary">${esc(code)}</span></h2><p class="text-sm text-on-surface-variant mt-1">${products.length} matching product${products.length === 1 ? '' : 's'} found.</p></div>
        <button id="back-to-trending-btn" type="button" class="min-h-[44px] px-4 py-2.5 rounded-xl bg-surface-container-lowest border border-outline-variant/40 text-sm font-semibold">Explore Trending</button>
      </div>
      ${products.length ? renderCardList(products, false) : '<div class="max-w-3xl mx-auto rounded-2xl border border-dashed border-outline-variant p-8 text-center text-sm text-on-surface-variant">No products match this Product ID or video code.</div>'}
      <section class="mt-10 sm:mt-12"><div class="max-w-3xl mx-auto mb-4"><h2 class="text-xl sm:text-2xl font-bold text-on-surface">Trending Products</h2><p class="text-sm text-on-surface-variant mt-1">Swipe horizontally to explore more trending items.</p></div>${renderCardList(data.trending, true)}</section>
    </section>`;
    const back = document.getElementById('back-to-trending-btn');
    if (back) back.addEventListener('click', resetToTrending);
  }

  function renderEmptyStateView(code) {
    viewport.innerHTML = `${dataStatus()}<div class="max-w-3xl mx-auto p-6 sm:p-10 rounded-2xl bg-surface-container-low border border-outline-variant/40 text-center"><div class="text-4xl mb-3">⌕</div><h2 class="text-xl sm:text-2xl font-bold text-on-surface">No Products Found for “${esc(code)}”</h2><p class="text-sm text-on-surface-variant mt-2 mb-5">Check the code and try again. Search checks both product_id and video_code in the published Sheets.</p><button id="empty-back-btn" type="button" class="min-h-[44px] px-5 py-2.5 rounded-xl bg-primary text-on-primary font-semibold">Back to Trending Products</button></div><section class="mt-10"><div class="max-w-3xl mx-auto mb-4"><h2 class="text-xl sm:text-2xl font-bold">Trending Products</h2></div>${renderCardList(data.trending, true)}</section>`;
    const back = document.getElementById('empty-back-btn');
    if (back) back.addEventListener('click', resetToTrending);
  }

  function showFeedback(message, type) {
    feedbackMsg.textContent = message;
    feedbackMsg.className = 'h-6 mt-2 text-center text-xs sm:text-sm flex items-center justify-center ' + (type === 'error' ? 'text-error font-semibold' : 'text-emerald-700 font-semibold');
  }
  function clearFeedback() { feedbackMsg.textContent = ''; feedbackMsg.className = 'h-6 mt-2 text-center text-xs sm:text-sm opacity-0'; }
  function performLookup(raw) {
    const code = String(raw || '').trim().toUpperCase();
    if (!code) { showFeedback('Please enter a Product ID or video code.', 'error'); codeInput.focus(); return; }
    activeCode = code;
    clearBtn.classList.remove('hidden');
    const ids = (data.searchMap && data.searchMap[code]) || data.codeMap[code] || [];
    if (ids.length) { showFeedback('Found ' + ids.length + ' matching product(s).', 'success'); renderSearchResultsView(code, ids); }
    else { showFeedback('No products found for ID or code ' + code + '.', 'error'); renderEmptyStateView(code); }
    viewport.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function resetToTrending() {
    activeCode = null;
    codeInput.value = '';
    clearBtn.classList.add('hidden');
    clearFeedback();
    renderTrendingView();
  }
  window.resetToTrending = resetToTrending;
  window.handleSearchSubmit = () => performLookup(codeInput.value);
  codeInput.addEventListener('input', e => clearBtn.classList.toggle('hidden', !e.target.value.trim()));
  clearBtn.addEventListener('click', () => { resetToTrending(); codeInput.focus(); });
  sampleChips.forEach(chip => chip.addEventListener('click', e => { const code = e.currentTarget.getAttribute('data-code'); codeInput.value = code; performLookup(code); }));

  async function copyText(value) {
    if (!value) throw new Error('No URL is available.');
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(value);
    const textarea = document.createElement('textarea');
    textarea.value = value; textarea.style.position = 'fixed'; textarea.style.opacity = '0';
    document.body.appendChild(textarea); textarea.select();
    const ok = document.execCommand('copy'); textarea.remove();
    if (!ok) throw new Error('Copy is not supported by this browser.');
  }
  async function shareProduct(product) {
    const url = new URL(window.location.href);
    url.searchParams.set('product', product.id);
    url.searchParams.set('source', product.source);
    const shareUrl = url.href;
    if (navigator.share) {
      try { await navigator.share({ title: product.title, text: 'View this product on ClipVault', url: shareUrl }); return; }
      catch (err) { if (err && err.name === 'AbortError') return; }
    }
    await copyText(shareUrl);
    window.showToast('Website product link copied', 'success');
  }

  viewport.addEventListener('click', async e => {
    const button = e.target.closest('[data-action], .color-choice');
    if (!button) return;
    if (button.classList.contains('color-choice')) {
      const card = button.closest('.product-card');
      if (card) updateGallery(card, Number(button.dataset.colorIndex), 0);
      return;
    }
    const product = getProductByUid(button.dataset.uid);
    if (!product) return;
    try {
      if (button.dataset.action === 'copy-video') {
        const videoUrl = safeUrl(product.videoUrl);
        if (!videoUrl) {
          window.showToast('Video URL not available', 'warning');
          return;
        }
        await copyText(videoUrl);
        window.showToast('Video URL copied successfully', 'success');
      } else if (button.dataset.action === 'share') await shareProduct(product);
      else if (button.dataset.action === 'gallery-next' || button.dataset.action === 'gallery-prev') {
        const gallery = button.closest('.product-card').querySelector('.product-gallery');
        const colorIndex = Number(gallery.dataset.colorIndex || 0);
        const color = product.colors[colorIndex] || product.colors[0];
        if (!color || color.images.length < 2) return;
        const current = Number(gallery.dataset.imageIndex || 0);
        const next = button.dataset.action === 'gallery-next' ? (current + 1) % color.images.length : (current - 1 + color.images.length) % color.images.length;
        updateGallery(button.closest('.product-card'), colorIndex, next);
      }
    } catch (err) { window.showToast(err.message || 'Action could not be completed'); }
  });

  function updateGallery(card, colorIndex, imageIndex) {
    const product = getProductByUid(card.dataset.uid);
    if (!product) return;
    const color = product.colors[colorIndex] || product.colors[0];
    if (!color || !color.images.length) return;
    const safeIndex = ((imageIndex % color.images.length) + color.images.length) % color.images.length;
    const gallery = card.querySelector('.product-gallery');
    const img = gallery.querySelector('.gallery-image');
    const placeholder = gallery.querySelector('.image-placeholder');
    if (img) { img.dataset.driveFallbackTried = ''; img.src = color.images[safeIndex]; img.alt = product.title + (color.name ? ' - ' + color.name : ''); img.style.display = ''; }
    if (placeholder) placeholder.classList.add('hidden');
    gallery.dataset.colorIndex = String(colorIndex);
    gallery.dataset.imageIndex = String(safeIndex);
    const counter = gallery.querySelector('.gallery-counter');
    if (counter) counter.textContent = color.images.length > 1 ? (safeIndex + 1) + ' / ' + color.images.length : '';
    card.querySelectorAll('.color-choice').forEach(btn => btn.classList.toggle('border-primary', Number(btn.dataset.colorIndex) === colorIndex));
    const hasMultiple = color.images.length > 1;
    gallery.querySelectorAll('.gallery-prev, .gallery-next').forEach(btn => btn.style.display = hasMultiple ? '' : 'none');
  }
  viewport.addEventListener('touchstart', e => {
    const gallery = e.target.closest('.product-gallery');
    if (gallery && e.touches.length === 1) gallery.dataset.touchStartX = String(e.touches[0].clientX);
  }, { passive: true });
  viewport.addEventListener('touchend', e => {
    const gallery = e.target.closest('.product-gallery');
    if (!gallery || !gallery.dataset.touchStartX || !e.changedTouches.length) return;
    const start = Number(gallery.dataset.touchStartX), end = e.changedTouches[0].clientX;
    delete gallery.dataset.touchStartX;
    if (Math.abs(end - start) < 35) return;
    const card = gallery.closest('.product-card');
    const product = card && getProductByUid(card.dataset.uid);
    if (!product) return;
    const colorIndex = Number(gallery.dataset.colorIndex || 0);
    const color = product.colors[colorIndex] || product.colors[0];
    if (!color || color.images.length < 2) return;
    const current = Number(gallery.dataset.imageIndex || 0);
    updateGallery(card, colorIndex, end < start ? current + 1 : current - 1);
  }, { passive: true });

  window.showToast = function (message, type) {
    const old = document.getElementById('clip-toast'); if (old) old.remove();
    const toast = document.createElement('div'); toast.id = 'clip-toast';
    toast.className = 'fixed bottom-5 left-1/2 -translate-x-1/2 px-4 py-2.5 rounded-xl shadow-2xl z-50 text-xs sm:text-sm text-center border ' + (type === 'success' ? 'bg-emerald-100 text-emerald-900 border-emerald-300' : type === 'warning' ? 'bg-amber-50 text-amber-900 border-amber-300' : 'bg-inverse-surface text-inverse-on-surface border-outline-variant/30');
    toast.textContent = message; document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 250); }, 2600);
  };

  viewport.innerHTML = '<div class="max-w-3xl mx-auto p-6 text-center text-sm text-on-surface-variant">Loading products from Google Sheets…</div>';
  function renderSharedProductView(product) {
    viewport.innerHTML = `${dataStatus()}<section class="w-full">
      <div class="max-w-3xl mx-auto mb-4 sm:mb-6"><h2 class="text-xl sm:text-2xl font-bold text-on-surface">Shared Product</h2><p class="text-sm text-on-surface-variant mt-1">This is the exact product shared with you.</p></div>
      ${renderCard(product, true)}
      <section class="mt-10 sm:mt-12"><div class="max-w-3xl mx-auto mb-4"><h2 class="text-xl sm:text-2xl font-bold text-on-surface">Trending Products</h2><p class="text-sm text-on-surface-variant mt-1">Swipe horizontally to explore more trending items.</p></div>${renderCardList(data.trending, true)}</section>
    </section>`;
    const target = document.getElementById('shared-product-card');
    if (target) {
      // Wait until the card is in the DOM before scrolling to and highlighting it.
      requestAnimationFrame(() => target.scrollIntoView({ behavior: 'smooth', block: 'center' }));
    }
  }

  window.PRODUCT_DATA_READY.then(() => {
    renderTrendingView();
    // Shared links render the exact product, then scroll to and highlight its full card.
    const params = new URLSearchParams(window.location.search);
    const sharedId = params.get('product');
    const sharedSource = params.get('source');
    if (sharedId) {
      const allProducts = [...data.meesho, ...data.trending];
      const product = allProducts.find(p => p.id === sharedId && (!sharedSource || p.source === sharedSource))
        || allProducts.find(p => p.id === sharedId);
      if (product) renderSharedProductView(product);
      else {
        viewport.innerHTML = `${dataStatus()}<div class="max-w-3xl mx-auto p-6 text-center rounded-2xl border border-dashed border-outline-variant"><h2 class="text-xl font-bold">Shared product not found</h2><p class="mt-2 text-sm text-on-surface-variant">This product may have been removed or its ID may have changed.</p><button id="shared-back-btn" type="button" class="mt-4 min-h-[44px] px-5 py-2.5 rounded-xl bg-primary text-on-primary font-semibold">Explore Trending</button></div>${renderCardList(data.trending, true)}`;
        const back = document.getElementById('shared-back-btn');
        if (back) back.addEventListener('click', resetToTrending);
      }
    }
  }).catch(() => {
    viewport.innerHTML = '<div class="max-w-3xl mx-auto p-6 text-center text-sm text-error">Product data could not be initialized. Please refresh the page.</div>';
  });
})();
