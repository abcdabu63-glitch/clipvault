/* ClipVault Google Sheets data connector.
 * The Sheets must remain published as CSV for public read access.
 * No private credentials or API keys are used in this browser-side loader.
 */
(function () {
  'use strict';

  const SHEETS = {
    trending: 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRl-Y9VS5eLeMpucrU1MWhskDTTL1o8O1brdRRc3AWr5-ErZ-TzEg-qCs4U_FOeVJ7ELW41QHnWXRz5/pub?gid=0&single=true&output=csv',
    meesho: 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRr2cFNVg4lLX9HqZWiBLhxxShKfN6r-cUPzuM_UOl-kJGqh-HjQeGg-2Rexe_XfQH53E0lT3nTbDN9/pub?gid=0&single=true&output=csv'
  };

  window.PRODUCT_DATA = { trending: [], meesho: [], codeMap: {}, searchMap: {}, errors: {} };
  window.PRODUCT_DATA_READY = loadAllSheets();

  function parseCSV(text) {
    const rows = [];
    let row = [], cell = '', quoted = false;
    text = String(text || '').replace(/^\uFEFF/, '');
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === '"') {
        if (quoted && text[i + 1] === '"') { cell += '"'; i++; }
        else quoted = !quoted;
      } else if (ch === ',' && !quoted) {
        row.push(cell); cell = '';
      } else if ((ch === '\n' || ch === '\r') && !quoted) {
        if (ch === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = '';
        if (row.some(v => String(v).trim() !== '')) rows.push(row);
        row = [];
      } else cell += ch;
    }
    if (cell.length || row.length) {
      row.push(cell);
      if (row.some(v => String(v).trim() !== '')) rows.push(row);
    }
    if (rows.length < 2) return [];
    const headers = rows.shift().map(normalizeHeader);
    return rows.map(values => {
      const obj = {};
      headers.forEach((header, i) => { if (header) obj[header] = String(values[i] == null ? '' : values[i]).trim(); });
      return obj;
    });
  }

  function normalizeHeader(value) {
    return String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_').replace(/[^a-z0-9_]/g, '').replace(/_+/g, '_');
  }

  function first(row, names) {
    for (const name of names) {
      const value = row[normalizeHeader(name)];
      if (value != null && String(value).trim() !== '') return String(value).trim();
    }
    return '';
  }

  function splitImageUrls(value) {
    if (!value) return [];
    return String(value).split(/\s*,\s*(?=https?:\/\/)/i).map(s => normalizeImageUrl(s.trim())).filter(isHttpUrl);
  }

  // Google Drive share links open a viewer page, not the image bytes expected by <img>.
  // Convert common public Drive sharing URLs to an image-serving URL automatically.
  function normalizeImageUrl(value) {
    if (!value) return '';
    const raw = String(value).trim();
    let match = raw.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/i);
    if (!match) match = raw.match(/[?&]id=([a-zA-Z0-9_-]+)/i);
    if (!match) match = raw.match(/googleusercontent\.com\/d\/([a-zA-Z0-9_-]+)/i);
    if (match && /(^|\.)drive\.google\.com$|googleusercontent\.com/i.test(new URL(raw).hostname)) {
      return 'https://lh3.googleusercontent.com/d/' + match[1];
    }
    return raw;
  }

  function isHttpUrl(value) {
    try { const url = new URL(String(value)); return url.protocol === 'https:' || url.protocol === 'http:'; }
    catch (_) { return false; }
  }

  function normalizeProduct(row, source, index) {
    const colors = [];
    Object.keys(row).forEach(key => {
      const match = key.match(/^color_(\d+)$/);
      if (!match) return;
      const n = match[1];
      const colorName = String(row[key] || '').trim();
      const images = splitImageUrls(row['images_' + n] || row['image_' + n] || row['image_urls_' + n] || '');
      if (colorName || images.length) colors.push({ name: colorName || ('Color ' + n), images, index: Number(n) });
    });
    colors.sort((a, b) => a.index - b.index);

    // Also accept a simple image/image_url column if color-image pairs are not used.
    if (!colors.length) {
      const singleImages = splitImageUrls(first(row, ['images', 'image_urls', 'image_url', 'image', 'product_image']));
      if (singleImages.length) colors.push({ name: '', images: singleImages, index: 1 });
    }

    const videoCode = first(row, ['video_code', 'video_code_id', 'code', 'creator_code']).toUpperCase();
    const productId = first(row, ['product_id', 'id', 'sku']);
    const bestSellerValue = first(row, ['best_sell', 'best_seller', 'bestseller', 'best seller']);
    // User-controlled Best_sell is a simple flag: any non-blank value means Best Seller.
    const bestSeller = bestSellerValue.trim().length > 0;
    const title = first(row, ['product_name', 'title', 'name', 'product']) || 'Product';
    return {
      uid: source + '-' + (productId || videoCode || index + 1) + '-' + index,
      source,
      id: productId || (source + '-' + (index + 1)),
      videoCode,
      title,
      productUrl: first(row, ['product_url', 'affiliate_url', 'buy_url', 'url']),
      videoUrl: first(row, ['video_url', 'video_url_link', 'creator_video', 'video_link']),
      price: first(row, ['price_range', 'price', 'price_range_inr', 'price_inr']),
      rating: first(row, ['rating', 'stars']),
      ratingCount: first(row, ['rating_count', 'ratings_count', 'review_count', 'reviews']),
      bestSeller,
      colors,
      description: first(row, ['description', 'product_description', 'details']),
      raw: row
    };
  }

  async function loadSheet(url, source) {
    // Add a unique query value so the browser/CDN is less likely to reuse stale published CSV.
    const freshUrl = new URL(url);
    freshUrl.searchParams.set('_clipvault_refresh', String(Date.now()) + '-' + Math.random().toString(36).slice(2));
    const response = await fetch(freshUrl.href, {
      method: 'GET',
      cache: 'no-store'
    });
    if (!response.ok) throw new Error('CSV request failed (' + response.status + ')');
    const text = await response.text();
    if (/^\s*<!doctype html|^\s*<html/i.test(text)) throw new Error('Google Sheets returned HTML instead of CSV. Check Publish to web settings.');
    const records = parseCSV(text).map((row, index) => normalizeProduct(row, source, index)).filter(p => p.title !== 'Product' || p.videoCode || p.id);
    return records;
  }

  async function loadAllSheets() {
    const jobs = await Promise.allSettled([
      loadSheet(SHEETS.trending, 'top'),
      loadSheet(SHEETS.meesho, 'meesho')
    ]);
    if (jobs[0].status === 'fulfilled') window.PRODUCT_DATA.trending = jobs[0].value;
    else window.PRODUCT_DATA.errors.top = jobs[0].reason && jobs[0].reason.message || 'Unable to load top sheet';
    if (jobs[1].status === 'fulfilled') window.PRODUCT_DATA.meesho = jobs[1].value;
    else window.PRODUCT_DATA.errors.meesho = jobs[1].reason && jobs[1].reason.message || 'Unable to load Meesho sheet';

    // Search by either Video Code or Product ID across both datasets.
    // A matching product is added only once even if the query matches both fields.
    [...window.PRODUCT_DATA.meesho, ...window.PRODUCT_DATA.trending].forEach(product => {
      const keys = [product.videoCode, product.id]
        .map(value => String(value || '').trim().toUpperCase())
        .filter(Boolean);
      [...new Set(keys)].forEach(key => {
        if (!window.PRODUCT_DATA.searchMap[key]) window.PRODUCT_DATA.searchMap[key] = [];
        if (!window.PRODUCT_DATA.searchMap[key].includes(product.uid)) {
          window.PRODUCT_DATA.searchMap[key].push(product.uid);
        }
      });
      if (product.videoCode) {
        if (!window.PRODUCT_DATA.codeMap[product.videoCode]) window.PRODUCT_DATA.codeMap[product.videoCode] = [];
        if (!window.PRODUCT_DATA.codeMap[product.videoCode].includes(product.uid)) {
          window.PRODUCT_DATA.codeMap[product.videoCode].push(product.uid);
        }
      }
    });
    return window.PRODUCT_DATA;
  }
})();
