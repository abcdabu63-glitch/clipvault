---
name: Lumen Key
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#474556'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#787587'
  outline-variant: '#c8c4d9'
  surface-tint: '#583bed'
  primary: '#451edb'
  on-primary: '#ffffff'
  primary-container: '#5e43f3'
  on-primary-container: '#e4deff'
  inverse-primary: '#c7bfff'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#00583b'
  on-tertiary: '#ffffff'
  tertiary-container: '#00734e'
  on-tertiary-container: '#6efbbd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4dfff'
  primary-fixed-dim: '#c7bfff'
  on-primary-fixed: '#170065'
  on-primary-fixed-variant: '#3f0fd6'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  code-lookup:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.05em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves a high-velocity affiliate discovery ecosystem designed for digital natives, video shoppers, and creators navigating video-tagged product lookups (YouTube Shorts, TikTok, Reels codes). The tone balances editorial curation with technical utility: immediate, authoritative, frictionless, and exceptionally transparent. 

The aesthetic synthesizes modern utility-first minimalism (Linear) with consumer precision and warm tactile restraint (Apple). Rather than feeling like a spam-heavy affiliate directory, it presents as a polished hardware spec-sheet crossed with a digital gallery. The layout leans into pristine whitespace, surgical line-work, crisp contrast typography, and high-legibility alphanumeric inputs. 

Key emotional goals:
- **Trust & Integrity:** Clear disclosure badges and verified lookup status eliminate affiliate fatigue.
- **Speed & Precision:** Instant retrieval feedback, micro-interactions, and keyboard-centric focus states.
- **Editorial Sophistication:** Quiet, balanced surfaces allow curated imagery and clear product data to dominate without sensory overload.

## Colors

The palette operates on a base of warm, slate-tinted white foundations layered with deep, hyper-legible slate typography and electrified by precise functional accents.

- **Primary (`#5E43F3` - Electric Iris):** Reserved for high-intent actions, primary lookup submission, live code indicators, and brand anchoring. It retains vivid luminance without eye-strain on light backgrounds.
- **Secondary (`#06B6D4` - Laser Cyan):** Applied to active states, instant-tag indicators, secondary telemetry chips, and real-time validation badges.
- **Tertiary (`#10B981` - Verified Emerald):** Denotes verified links, in-stock confirmations, transparent affiliate disclosure tags, and savings callouts.
- **Neutral (`#0F172A` - Obsidian Slate):** Establishes the typographic weight, structural dividers, and high-contrast foreground layers.

### Surface Color Mapping
- `surface-canvas`: `#FAFAF9` (warm off-white foundation that eliminates eye fatigue)
- `surface-subtle`: `#F1F5F9` (secondary card containers, inputs, and tab backgrounds)
- `surface-elevated`: `#FFFFFF` (primary cards, popovers, and sticky search bars)
- `border-hairline`: `rgba(15, 23, 42, 0.08)` (whisper-thin perimeter definition)
- `border-focus`: `rgba(94, 67, 243, 0.35)` (glowing chromatic ring)
- `text-primary`: `#0F172A`
- `text-secondary`: `#475569`
- `text-tertiary`: `#94A3B8`

## Typography

The typographic hierarchy utilizes three complementary typefaces to clearly demarcate intent:

1. **Headlines (`Space Grotesk`):** Provides a contemporary, subtle geometric edge for titles, hero statements, and category milestones. Keeps the interface modern and technical without tipping into aggressive brutalism.
2. **Body & Interface (`Inter`):** Renders descriptions, affiliate disclosures, meta information, and dialog messaging with neutral, optimized readability across sub-pixel environments.
3. **Lookup & Badges (`JetBrains Mono`):** Dedicated to user-facing code inputs (e.g., `#CREATOR24`, `SHORTS-889`), affiliate tag chips, pricing metrics, and technical verification stamps. The fixed-width character slots ensure codes are instantly scannable without character ambiguity (`0` vs `O`, `1` vs `l`).

## Layout & Spacing

The layout is constructed on a 12-column dynamic responsive grid anchored by an 8pt baseline rhythm (supplemented by 4pt micro-steps for compact indicators).

### Breakpoints & Layout Adaptations
- **Desktop (1280px+):** 12 columns, fixed maximum canvas container of 1240px, 24px (`1.5rem`) gutters, and dynamic outer margins centered horizontally. Complex cards display split content: product photography left, metadata, disclosures, and direct-out action right.
- **Tablet (768px - 1279px):** 8 columns, 20px gutters, and 32px (`2rem`) margins. Affiliate discovery grid condenses to 2-column stacked modules.
- **Mobile (Under 768px):** 4 columns, 16px (`1rem`) gutters, and 16px (`1rem`) page margins. Floating hero search bar docks fixed at top/bottom viewport boundaries. Product modules switch to horizontal compact rows with thumbnail previews.

### Spacing Usage
- `space-xs (4px)`: Micro-padding between badge icons and text, affiliate disclosure indicator dots.
- `space-sm (8px)`: Padding inside pill tags, gap between metadata rows.
- `space-md (16px)`: Padding within cards, inputs, and modular element groupings.
- `space-lg (24px)`: Vertical stack spacing between distinct functional card sections.
- `space-xl (40px)`: Section rhythm dividers and landing headers.

## Elevation & Depth

Visual hierarchy uses a refined hybrid approach: **tonal layering combined with luminous ambient shadows and hairline borders.** Harsh drop shadows are prohibited.

### Elevation Hierarchy
- **Level 0 (Canvas Base):** Flat `#FAFAF9`. No shadow. Forms the infinite scroll backdrop.
- **Level 1 (Subtle Containers / Recessed Fields):** `#F1F5F9` background, hairline border `1px solid rgba(15, 23, 42, 0.05)`. Used for inactive input wrappers and filter toolbars.
- **Level 2 (Cards & Surface Modules):** `#FFFFFF` surface with `1px solid rgba(15, 23, 42, 0.08)` and shadow `0 1px 3px rgba(15, 23, 42, 0.04), 0 8px 24px -4px rgba(15, 23, 42, 0.03)`.
- **Level 3 (Focused Search, Floating Code Lookups, Modals):** Pure white `#FFFFFF` surface with `1px solid rgba(94, 67, 243, 0.18)` and an extended ambient shadow: `0 20px 40px -15px rgba(15, 23, 42, 0.08), 0 0 0 1px rgba(94, 67, 243, 0.08)`.
- **Glass Elements (Sticky Navigation & Search Shell):** `rgba(255, 255, 255, 0.85)` with `backdrop-filter: blur(16px)` and a subtle bottom border `rgba(15, 23, 42, 0.06)`.

## Shapes

The design uses `Level 2 (Rounded)` architecture balanced with selective pill primitives:

- **Cards, Modals, and Main Surfaces:** Built with `rounded-lg` (16px / `1rem`) and `rounded-xl` (24px / `1.5rem`) on larger desktop modules. Corners are smoothed to prevent visual harshness.
- **Inputs & Interactive Fields:** Feature consistent 12px corner radii for an engineered, tactile feel.
- **Affiliate Chips, Code Tags, and Status Badges:** Fully rounded pill-shapes (`border-radius: 9999px`) to immediately signal interactive or metadata categorization distinct from layout cards.
- **Image Containers:** Clamped to inner matching corner radius (`12px`) with zero edge bleeding.

## Components

### Code Lookup & Hero Search
- **Structure:** Unified floating container with an active state border highlight.
- **Input Field:** Employs `JetBrains Mono` (`code-lookup`), automatic uppercase transformation, clear-all micro icon, and embedded shortcut key indicators (`Ctrl + K` / `⌘K`).
- **Submit / Lookup Button:** Embedded inside the right border of the input field. High-contrast Electric Iris background, white typography, icon chevron transitions.

### Product & Affiliate Cards
- **Structure:** Crisp white elevated card with 1px border. 
- **Visuals:** Top or left quadrant houses edge-padded product image with subtle neutral badge specifying video timestamp or creator avatar.
- **Affiliate Disclosure:** Explicit badge at top-right utilizing `tertiary` tone: green micro indicator dot paired with `AFFILIATE LINK` or `SPONSORED` in `label-sm`. Non-obtrusive yet fully legally compliant and trust-building.
- **Code Box:** A dashed or hairline-bordered monospace cell within the card with a 1-click "Copy Code & Open" trigger.

### Buttons
- **Primary:** `#5E43F3` background, `#FFFFFF` text, subtle inset highlight `inset 0 1px 0 rgba(255, 255, 255, 0.2)`. On hover: `#4F35E2`, transition 150ms ease.
- **Secondary:** Surface `#FFFFFF`, border `1px solid rgba(15, 23, 42, 0.12)`, text `#0F172A`. On hover: surface `#F8FAFC`.
- **Affiliate CTA Button:** Gradient micro-border or high-contrast slate with secondary cyan active state, accompanied by an external link icon.

### Chips & Pill Tags
- **Category Chips:** Slate base, `8px` vertical / `14px` horizontal padding, `label-md` font. Hover provides subtle elevation.
- **Creator / Short Source Chip:** Pill format featuring a micro platform icon (YouTube icon silhouette) + video title truncate.

### Checkboxes & Toggle Controls
- Custom squared-rounded (6px) checkboxes using primary color fills with crisp geometric checkmarks. Radio options feature concentric target rings.

### Notification & Instant Feedback Toasts
- Bottom-center docked pill alerts showing copied affiliate codes: `#0F172A` dark slate pill, white text, green checkmark icon, entering with a slight spring curve.